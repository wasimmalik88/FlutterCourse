import 'package:flutter/material.dart';

Color primaryColor = Colors.red;
