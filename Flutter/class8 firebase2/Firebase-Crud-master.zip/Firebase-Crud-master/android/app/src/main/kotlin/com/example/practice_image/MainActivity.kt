package com.example.practice_image

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
